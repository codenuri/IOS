import Foundation

class Car
{
    func go() { print("Car go")}
    
    init() { print("Car init")}
    deinit { print("Car deinit")}
}

func f1()
{
    var c1 : Car? = Car()
    var c2 = c1

    print("----------- [A]")
    c1 = nil
    print("----------- [B]")
}

func f2()
{
    var c1 : Car? = Car()
    weak var c2 = c1
    
    c2!.go()
    print("----------- [A]")
    c1 = nil
    print("----------- [B]")
//    c2!.go()
}
//f1()
f2()




