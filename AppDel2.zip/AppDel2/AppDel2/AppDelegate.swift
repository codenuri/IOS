//
//  AppDelegate.swift
//  AppDel2
//
//  Created by codenuri on 2022/05/31.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }




}

