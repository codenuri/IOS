import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
        window = UIWindow()
        window?.backgroundColor = .white

        let rc = CGRect(x: 100, y: 200, width: 200, height: 400)
        let view = UIView(frame: rc)
        view.backgroundColor = .yellow
        window?.addSubview(view)
        
//      let btn = UIButton(type: UIButton.ButtonType.roundedRect)
        let btn = UIButton(type: .roundedRect)
        
        btn.frame = CGRect(x: 50, y: 100, width: 100, height: 100)
        btn.backgroundColor  = UIColor.green
        view.addSubview(btn)
        
        
        
        
        
        window?.rootViewController = UIViewController()
        window?.makeKeyAndVisible()
        
        return true
    }
}

