//
//  main.swift
//  AppDel1
//
//  Created by codenuri on 2022/05/31.
//

import Foundation
import UIKit

let argc = CommandLine.argc
let argv = UnsafeMutableRawPointer(CommandLine.unsafeArgv)
    .bindMemory(to: UnsafeMutablePointer<Int8>?.self, capacity: Int(CommandLine.argc))

UIApplicationMain(argc, argv, nil, NSStringFromClass(AppDelegate.self))



