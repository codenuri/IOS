//
//  AppDelegate.swift
//  AppDel1
//
//  Created by codenuri on 2022/05/31.
//

import Foundation
import UIKit

@main 
class AppDelegate : UIResponder, UIApplicationDelegate
{
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        // UI code 작성..
        print("launch app")
        
        return true
    }
}
