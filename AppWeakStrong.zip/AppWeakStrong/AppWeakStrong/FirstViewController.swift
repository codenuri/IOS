import UIKit

class FirstViewController: UIViewController
{
   
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet var label2: UILabel!
    
    @IBAction func click1(_ sender: Any)
    {
        label1.removeFromSuperview()
    }
    
    @IBAction func click2(_ sender: Any)
    {
        self.view.addSubview(label1)
    }
        
    @IBAction func click3(_ sender: Any)
    {
        label2.removeFromSuperview()
    }
        
    @IBAction func click4(_ sender: Any)
    {
        self.view.addSubview(label2)
    }
        
    @IBAction func click5(_ sender: Any)
    {
    }
    
    @IBAction func click6(_ sender: Any)
    {
  
    }
    
}
