import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool
    {
        
 
        make_ui_2()
        return true
    }
    func make_ui_1()
    {
        window = UIWindow()
        window?.backgroundColor = .white
        
        let rvc = RedViewController(nibName: "RedViewController", bundle: nil)
        
        let gvc = GreenViewController(nibName: "GreenViewController", bundle: nil)

        let arr = [rvc, gvc]
                
        let tvc = UITabBarController()
        tvc.viewControllers = arr
        
        tvc.tabBar.items?[0].title = "RED"
        tvc.tabBar.items?[1].title = "GREEN"
        
        
        window?.rootViewController = tvc
        window?.makeKeyAndVisible()
    }
    
    func make_ui_2()
    {
        window = UIWindow()
        window?.backgroundColor = .white
        
        let rvc = RedViewController(nibName: "RedViewController", bundle: nil)
        
        let gvc = GreenViewController(nibName: "GreenViewController", bundle: nil)

        
        let nvc = UINavigationController(rootViewController: gvc)
        
        
        let arr = [rvc, nvc]
                
        let tvc = UITabBarController()
        tvc.viewControllers = arr
        
        tvc.tabBar.items?[0].title = "RED"
        tvc.tabBar.items?[1].title = "GREEN"
        
        
        window?.rootViewController = tvc
        window?.makeKeyAndVisible()
    }

}

