
import UIKit

class GreenViewController: UIViewController
{

    @IBAction func click(_ sender: Any)
    {
        let vc = YellowViewController(nibName: "YellowViewController", bundle: nil)
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
