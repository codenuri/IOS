import UIKit

class FirstViewController: UIViewController
{

    @IBOutlet weak var msgLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()


    }

    @IBAction func click()
    {
        msgLabel.text = "hello"
    }
    
}
