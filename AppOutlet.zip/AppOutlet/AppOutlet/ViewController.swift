import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
    
    @IBAction func click1(_ sender: Any)
    {
        let btn = sender as! UIButton
        
        let s = btn.titleLabel?.text
        
        print(String(describing: s))
    }
    
    
    @IBAction func click2(_ sender: UIButton, forEvent event: UIEvent)
    {
        let s = sender.titleLabel?.text
        
        print(String(describing: s))
        
    }
    
}

