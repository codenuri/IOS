import UIKit

class FirstViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    
    
    @IBAction func button_click()
    {
        print("button_click")
    }
    
}
