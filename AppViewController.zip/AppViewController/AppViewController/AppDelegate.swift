import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
        window = UIWindow()
        window?.backgroundColor = .white

        let rc = CGRect(x: 100, y: 200, width: 200, height: 400)
        let view = UIView(frame: rc)
        view.backgroundColor = .yellow
        //window?.addSubview(view)
        
        let btn = UIButton(type: .roundedRect)
        btn.frame = CGRect(x: 50, y: 100, width: 100, height: 100)
        btn.backgroundColor  = .green
        view.addSubview(btn)
        
        let vc = FirstViewController()
        vc.view = view
        
        window?.rootViewController = vc   // vc.view를 Window에 자동으로 부착
        
        window?.makeKeyAndVisible()

        
        btn.addTarget(vc,
            action: #selector(FirstViewController.button_click ),
            for: UIControl.Event.touchUpInside)
        
        return true
    }
}

