import Foundation
import UIKit

@main
class AppDelegate : UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool
    {
//        using_xib()
        
//        using_storyboard()
        
        return true
    }
/*
    func using_xib()
    {
        window = UIWindow()
        window?.backgroundColor = .white
        
        let vc = RedViewController(nibName: "RedViewController", bundle: nil)
        
        window?.rootViewController = vc
        window?.makeKeyAndVisible()
    }
    
    func using_storyboard()
    {
        window = UIWindow()
        window?.backgroundColor = .white
        
        let sb = UIStoryboard(name: "mystory", bundle: nil)
//      let vc = sb.instantiateViewController(withIdentifier: "First")
        
        let vc = sb.instantiateInitialViewController()
        
        
        window?.rootViewController = vc
        window?.makeKeyAndVisible()
    }
    */
}

















