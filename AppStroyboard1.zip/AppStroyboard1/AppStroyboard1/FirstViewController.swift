
import UIKit

class FirstViewController: UIViewController {

   

    @IBAction func click(_ sender: Any)
    {
        print("click")
    }
   

}
