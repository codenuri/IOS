//
//  ViewController.swift
//  AppStoryboard2
//
//  Created by codenuri on 2022/06/04.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

