

import UIKit

class YellowViewController: UIViewController {


    @IBAction func click(_ sender: Any)
    {
        print("click")
    }
}
