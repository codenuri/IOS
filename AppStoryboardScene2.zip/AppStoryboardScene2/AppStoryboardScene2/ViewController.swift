import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let dst = segue.destination as! YellowViewController
        
        //dst.label.text = "Hello"
        
        dst.msg = "Hello"
        
    }

    
}

