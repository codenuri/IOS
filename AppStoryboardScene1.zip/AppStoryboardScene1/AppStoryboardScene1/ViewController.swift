import UIKit

class ViewController: UIViewController
{

    @IBAction func click1(_ sender: Any)
    {
        let sb = self.storyboard
        let vc = sb?.instantiateViewController(withIdentifier: "Yellow")
        
        self.present(vc!, animated: true)
    }
    
    @IBAction func click2(_ sender: Any)
    {
        self.performSegue(withIdentifier: "YellowScene", sender: self)
    }
    
    @IBAction func finish(_ segue: UIStoryboardSegue)
    {
        print("finish")
    }
}

