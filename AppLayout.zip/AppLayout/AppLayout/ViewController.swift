import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var textfield: UITextField!
    
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        /*
        textfield.translatesAutoresizingMaskIntoConstraints = false
        button.translatesAutoresizingMaskIntoConstraints = false
        
        // textField!.centerY = self.view.centerY * 1.0 + 0
        let ct1 = NSLayoutConstraint(item: textfield!, attribute: .centerY,
                                     relatedBy: .equal, toItem: self.view, attribute: .centerY,
                                     multiplier: 1.0, constant: 0)
        
        self.view.addConstraint(ct1)
        
        let ct2 = NSLayoutConstraint(item: textfield!, attribute: .centerX,
                                     relatedBy: .equal, toItem: self.view, attribute: .centerX,
                                     multiplier: 1.0, constant: 0)
        
        self.view.addConstraint(ct2)
        
        // textField!.width = self.view..width * 0.5 + 0
        let ct3 = NSLayoutConstraint(item: textfield!, attribute: .width,
                                     relatedBy: .equal, toItem: self.view, attribute: .width,
                                     multiplier: 0.5, constant: 0)
        
        self.view.addConstraint(ct3)

        let ct4 = NSLayoutConstraint(item: button!, attribute: .width,
                                     relatedBy: .equal, toItem: textfield!, attribute: .width,
                                     multiplier: 0.5, constant: 0)
        
        self.view.addConstraint(ct4)
        
        // button!.top = textfield!.bottom * 1.0 + 10
        let ct5 = NSLayoutConstraint(item: button!, attribute: .top,
                                     relatedBy: .equal, toItem: textfield!, attribute: .bottom,
                                     multiplier: 1.0, constant: 10)
        
        self.view.addConstraint(ct5)
        
        let ct6 = NSLayoutConstraint(item: button!, attribute: .centerX,
                                     relatedBy: .equal, toItem: self.view, attribute: .centerX,
                                     multiplier: 1.0, constant: 0)
        
        self.view.addConstraint(ct6)
     */
    }
}

