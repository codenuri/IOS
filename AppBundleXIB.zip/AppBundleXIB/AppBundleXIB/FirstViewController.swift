import UIKit

class FirstViewController: UIViewController
{

    @IBAction func click(_ sender: Any)
    {
        let bundle = Bundle.main

        let arr = bundle.loadNibNamed("myxib", owner: nil, options: nil)
        
        let c = arr![0] as! Car
        
        c.go()
        
        
        let btn = arr![1] as! UIButton
        
        btn.frame = CGRect(x: 0, y: Int.random(in: 0...700), width: 50, height: 50)
        
        self.view.addSubview(btn)
    }

}
