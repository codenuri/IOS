import Foundation

class Car : NSObject
{
    func go()
    {
        print("Car go")
    }
}
