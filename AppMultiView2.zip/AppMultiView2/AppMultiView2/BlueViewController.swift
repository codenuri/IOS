import UIKit

class BlueViewController: UIViewController
{
    
    @IBAction func click(_ sender: Any)
    {
        self.dismiss(animated: true)
    }

}
