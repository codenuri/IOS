import UIKit

class RedViewController: UIViewController
{
    @IBAction func click1(_ sender: Any)
    {
        let vc = GreenViewController(nibName: "GreenViewController", bundle: nil)
        
        let app = UIApplication.shared
        let appdel = app.delegate as! AppDelegate
        appdel.window?.rootViewController = vc
    }
    
    @IBAction func click2(_ sender: Any)
    {
        let vc = GreenViewController(nibName: "GreenViewController", bundle: nil)
        
        self.present(vc, animated: true)

    }
    
    @IBAction func click3(_ sender: Any)
    {
        let vc = BlueViewController(nibName: "BlueViewController", bundle: nil)
        
        vc.modalTransitionStyle = .flipHorizontal
        
        self.present(vc, animated: true)
    }
}
