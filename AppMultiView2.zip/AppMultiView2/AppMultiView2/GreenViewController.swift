import UIKit

class GreenViewController: UIViewController
{

    @IBAction func click(_ sender: Any)
    {
        self.dismiss(animated: true)
        
    }
}
