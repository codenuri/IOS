import UIKit

class RedViewController: UIViewController
{
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationItem.title = "RED"
    }
    
    @IBAction func click(_ sender: Any)
    {
        let vc = GreenViewController(nibName: "GreenViewController", bundle: nil)
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
