import UIKit

class GreenViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationItem.title = "GREEN"
    }
    
    @IBAction func click(_ sender: Any)
    {
        let vc = YellowViewController(nibName: "YellowViewController", bundle: nil)
        
        self.navigationController?.pushViewController(vc, animated: true)
  
    }
}
