import Foundation
import UIKit

@main
class AppDelegate : UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool
    {
        
        window = UIWindow()
        window?.backgroundColor = .white
        
        let vc = RedViewController(nibName: "RedViewController",
                                   bundle: nil)

        let nvc = UINavigationController(rootViewController: vc)
        
        
        
        
        window?.rootViewController = nvc
        
        
        window?.makeKeyAndVisible()
        
        return true
    }
}

















