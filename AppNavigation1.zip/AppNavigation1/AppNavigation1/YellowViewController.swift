import UIKit

class YellowViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationItem.title = "YELLOW"
    }
}
