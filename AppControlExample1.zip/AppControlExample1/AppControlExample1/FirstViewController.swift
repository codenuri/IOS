import UIKit

class FirstViewController: UIViewController
{
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var txtField: UITextField!
    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet      var imgView2: UIImageView!
    
    @IBAction func click1(_ sender: Any)
    {
        label.text = txtField.text
    }
    
    @IBAction func click2(_ sender: Any)
    {
        let rc = UIScreen.main.bounds
        
        imgView1.center.x = rc.width
        
        
        UIView.animate(withDuration: 1,
                       animations: { self.imgView1.center.x = 0  },
                       completion: nil)
        
        
        
    }
    
    @IBAction func click3(_ sender: Any)
    {
        self.view.addSubview(imgView2)
        
        let rc = UIScreen.main.bounds
        
        imgView2.center.y = rc.height / 2 + 200
        imgView2.center.x = rc.width
        
        
        UIView.animate(withDuration: 1,
                       animations: { self.imgView2.center.x = 0  },
                       completion: { (finish:Bool)->Void in self.imgView2.removeFromSuperview()      }  )
        
//        imgView2.removeFromSuperview()
        
        
    }
    
    @IBAction func click4(_ sender: Any)
    {
        let img = UIImage(named: "car.png")
        let imgView3 = UIImageView(image: img)
        
        imgView3.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        
        
        self.view.addSubview(imgView3)
        
        let rc = UIScreen.main.bounds
        
        imgView3.center.y = rc.height / 2 + 200
        imgView3.center.x = rc.width
        
        
        UIView.animate(withDuration: 1,
                       animations: { imgView3.center.x = 0  },
                       completion: { (finish:Bool)->Void in imgView3.removeFromSuperview()      }  )
    }
    
}
