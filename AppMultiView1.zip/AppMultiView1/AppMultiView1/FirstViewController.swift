import UIKit

class FirstViewController: UIViewController
{

    @IBOutlet var secondview: UIView!
    
    @IBAction func click1(_ sender: Any)
    {
        self.view = secondview
        
    }
    
    
    
    @IBAction func click2(_ sender: Any)
    {
//      self.view.addSubview(secondview)
        self.view.insertSubview(secondview, at: 0)
        
        
        let rc = UIScreen.main.bounds
        
        secondview.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        
        secondview.transform = CGAffineTransform.init(rotationAngle:3.14)
        
         
        UIView.animate(withDuration: 1,
                       animations: { self.secondview.frame = CGRect(x: 0, y: 0, width: rc.width, height: rc.height)
                                     self.secondview.transform = CGAffineTransform.init(rotationAngle:0)
                                   },
                       completion: nil)
        
        

    }
    
    
    @IBAction func click3(_ sender: Any)
    {
//        secondview.removeFromSuperview()
     
        let rc = UIScreen.main.bounds
        
        secondview.frame = CGRect(x: 0, y: 0, width: rc.width, height: rc.height)
        
        secondview.transform = CGAffineTransform.init(rotationAngle:0)
        
         
        UIView.animate(withDuration: 1,
                       animations: { self.secondview.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
                        self.secondview.transform = CGAffineTransform.init(rotationAngle:3.14)
                                   },
                       
                       completion: { (finish : Bool)->Void in self.secondview.removeFromSuperview() })
    }
        
}
 
