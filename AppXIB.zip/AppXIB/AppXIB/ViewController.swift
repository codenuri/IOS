import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    
    @IBAction func button_click(_ sender: Any)
    {
        print("button_click")
    }
}

