import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate
{
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
 //       make_ui_using_code()
   
        make_ui_using_xib()
        
        return true
    }
    
    func make_ui_using_code()
    {
        // 1. window 생성
        window = UIWindow()
        window?.backgroundColor = .white
        
        // 2. view 생성
        let rc = CGRect(x: 100, y: 200, width: 200, height: 400)
        let view = UIView(frame: rc)
        view.backgroundColor = .yellow
        
        // 3. button 생성
        let btn = UIButton(type: .roundedRect)
        btn.frame = CGRect(x: 50, y: 100, width: 100, height: 100)
        btn.backgroundColor  = .green
        view.addSubview(btn)
        
        // 4. ViewController 생성
        let vc = ViewController()
        vc.view = view

        // 5. 버튼이벤트 핸들러 연결
        // btn.addTarget(vc, action: #selector(ViewController.button_click ), for: UIControl.Event.touchUpInside)

        // 6. 윈도우에 연결
        window?.rootViewController = vc
        window?.makeKeyAndVisible()
    }
    
    
    func make_ui_using_xib()
    {
        // 1. window 생성
        window = UIWindow()
        window?.backgroundColor = .white
        
         
        // 4. ViewController 생성
//      let vc = ViewController()
//      vc.view = view
        
        let vc = ViewController(nibName: "myxib1", bundle: nil)
  
        // 6. 윈도우에 연결
        window?.rootViewController = vc
        window?.makeKeyAndVisible()
    }
    
}

