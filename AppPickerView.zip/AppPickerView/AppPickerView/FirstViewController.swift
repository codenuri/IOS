import UIKit

class FirstViewController : UIViewController,
                            UIPickerViewDataSource,
                            UIPickerViewDelegate
{
    var animals = ["사자", "호랑이", "뱀"]
    var fruits  = ["사과", "배", "오렌지", "바나나"]
    
    @IBOutlet weak var pv: UIPickerView!
    @IBOutlet weak var label: UILabel!
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if component == 0
        {
            return 2
        }
        
        let idx = pv.selectedRow(inComponent: 0)
        
        if idx == 0
        {
            return animals.count
        }
        
        return fruits.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        if component == 0
        {
            if row == 0
            {
                return "동물"
            }
            return "과일"
        }
        
        let idx = pv.selectedRow(inComponent: 0)
        
        if idx == 0
        {
            return animals[row]
        }
        return fruits[row]
        
    }

    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if component == 0
        {
            pv.reloadComponent(1)
            pv.selectRow(0, inComponent: 1, animated: true)
        }
        else
        {
            let idx = pv.selectedRow(inComponent: 0)
            
            if idx == 0
            {
                label.text = animals[row]
            }
            else
            {
                label.text = fruits[row]
            }
            
            
        }
        
    }
    
    @IBAction func click(_ sender: Any)
    {
        pv.selectRow(0, inComponent: 0, animated: true)
        pv.selectRow(0, inComponent: 1, animated: true)
    }

}
