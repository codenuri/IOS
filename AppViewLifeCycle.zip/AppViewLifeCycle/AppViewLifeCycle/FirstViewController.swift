import UIKit

class FirstViewController: UIViewController
{
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

     }
}
